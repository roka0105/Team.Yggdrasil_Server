using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;
using UnityEngine;

/*dontdestroy 안한 이유는 게임이 끝나면 씬이 변하고 새 게임을 선택하게 될텐데 일일히 데이터를 초기화 하지 않기 위해서.
  어차피 게임 진행은 한 씬에서 이루어 질 테니까 해당 게임이 끝나면 매니저들에 담긴 데이터 정보들이 자동 초기화 되도록.
 */
namespace Singleton_Ver1
{
    public class Singleton<T> : MonoBehaviour where T : MonoBehaviour
    {
        [SerializeField]

        protected bool flag;
        private static T instance;
        public static T Instance
        {
            get
            {
                Singleton_Ver1.Singleton<T>[] objs = FindObjectsOfType<Singleton_Ver1.Singleton<T>>(true);
                GameObject obj;
                if (objs.Length < 0)
                {
                    obj = objs.Where(item => item.flag == true).FirstOrDefault().gameObject;
                }
                else obj = null;
                if (obj == null)
                {
                    if (objs.Length > 0)
                    {
                        return objs[0].GetComponent<T>();
                    }
                    obj = new GameObject(typeof(T).Name);
                    obj.AddComponent<T>();
                }
                else
                {
                    instance = obj.GetComponent<T>();
                }
                return instance;
            }
        }
    }

}

//Lazy singleton 멀티 스레드 환경에서 lock대신 사용하는데 선언 즉시 생성이 아니라 호출 시점에 생성,생성 시점을 조절 할 수 있음.
/*1.생성이 오래걸리는 큰 오브젝트 필요할때만 생성하고 싶을때
  2.리소스를 많이 사용하는 실행을 필요할때만 할때
  3.자원 생성을 멀티 스레드 환경에서 안전하게 해야 할 때
  */
namespace Singleton_Ver2
{
    public class Singleton<T> : MonoBehaviour where T : MonoBehaviour
    {
        [SerializeField]
        protected bool flag;
        private static readonly Lazy<T> _instance =
        new Lazy<T>(() =>
        {
            GameObject obj = null;
            Singleton_Ver2.Singleton<T>[] objs = FindObjectsOfType<Singleton_Ver2.Singleton<T>>(true);
            if (objs.Length > 0)
            {
                obj = objs.Where(item => item.flag == true).FirstOrDefault().gameObject;
                return objs[0].GetComponent<T>();
            }
            if (obj == null)
            {
                obj = new GameObject(typeof(T).Name);
                //Transform parent = GameObject.Find("Managers").transform;
                //if (parent == null)
                //{
                //    parent = new GameObject("Managers").transform;
                //}
                //obj.transform.SetParent(parent);
                obj.AddComponent<T>();
            }
            return obj.GetComponent<T>();

        });
        public static void __Initialize()
        {
            T instance = _instance.Value;
        }
        public static T Instance
        {
            get
            {
                return _instance.Value;
            }
        }
    }
}