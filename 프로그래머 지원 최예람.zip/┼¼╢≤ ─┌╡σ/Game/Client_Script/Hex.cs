using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class Hex
{
    public enum TileType
    {
        None=-1,
        Move = 0,
        Wall
    }
    public enum AroundType
    {
        LeftUp = 0,
        RightUp,
        Left,
        Right,
        LeftDown,
        RightDown
    }
    Vector3[] vertex = new Vector3[6];
    Vector3 senter = new Vector3(0, 0, 0);
    static float radius = 17;
    const int COUNT = 6;
    const float PI = 3.141592f;

    #region AStar member
    int id;
    int aroundcount = 0;
    //좌상,우상,좌,우,좌하,우하 순으로 담기.
    Hex[] around_tile;
    TileType tile_type;
    int G;
    int H;
    Hex prev;
    Hex next;
    #endregion
    public int GetX
    {
        get => id % aroundcount;
    }
    public int GetY
    {
        get => id / aroundcount;
    }
    public int _G
    {
        get => G;
        private set => G = value;
    }
    public int _H
    {
        get => H;
        private set => H = value;
    }
    public int GetF
    {
        get => G + H;
    }
    public int ID
    {
        get => id;
        set => id = value;
    }

    public Vector3 SenterPos
    {
        get => senter;
    }
    public static float Radius
    {
        get => radius;
    }
   
    public Hex()
    {

    }
    public Hex(int _id)
    {
        id = _id;
    }
    public Hex(Vector3 _sendter, float _radius, int arround)
    {
        senter = _sendter;
        radius = _radius;
        aroundcount = arround;
        around_tile = new Hex[arround];
        tile_type = TileType.Move;
        prev = null;
        next = null;
    }
    public Hex(Vector3 _sendter, float _radius)
    {
        senter = _sendter;
        radius = _radius;
    }
    public Vector3[] GetVertex
    {
        get => vertex;
    }
    public TileType _TileType
    {
        get => tile_type;
        set => tile_type = value;
    }
    public Hex Prev
    {
        get => prev;
    }
    public void SetParent(Hex _parent)
    {
        prev = _parent;
    }
    public void SetCost(int _g, int _h)
    {
        if (_g != -1)
        {
            _G = _g;
        }
        if (_h != -1)
        {
            _H = _h;
        }
    }
    public void AddAroundTile(Hex _hex, AroundType _type)
    {
        around_tile[(int)_type] = _hex;
    }
    public Hex[] GetAroundTile()
    {
        return around_tile;
    }
    public void FindingClear()
    {
        _G = 0;
        _H = 0;
        prev = null;
        next = null;
    }

    public bool InHex(Vector3 _objpos)
    {
        if (Mathf.Abs(_objpos.x - senter.x) < radius && Mathf.Abs(_objpos.z - senter.z) < radius)
        {
            return true;
        }
        else
            return false;
    }
    public void CreateVertex()
    {
        for (int i = 0; i < COUNT; i++)
        {
            vertex[i] = Point_Hex_Corner(senter, radius, i);
        }

    }
    private Vector3 Point_Hex_Corner(Vector3 _center, float _length, int _count)
    {
        float angle_deg = 60 * _count - 30;
        float angle_rad = PI / 180 * angle_deg;

        return new Vector3(_center.x + _length * Mathf.Cos(angle_rad), 0f, _center.z + _length * Mathf.Sin(angle_rad));
    }


    public void PrintAround()
    {
        for (int i = 0; i < 6; i++)
        {
            Debug.Log("around" + i + ": " + around_tile[i].id);
        }
    }

}
