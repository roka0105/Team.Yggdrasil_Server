using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Aroundtype = Hex.AroundType;
public class AStarYR : MonoBehaviour
{
    List<Hex> close_tiles;
    List<Hex> open_tiles;
    List<Hex> path_tiles;
    Hex start_tile;
    Hex end_tile;

    int cost1 = 1;
   
    public AStarYR()
    {

    }
    public AStarYR(Hex _start,Hex _end)
    {
        start_tile = _start;
        end_tile = _end;
        close_tiles = new List<Hex>();
        open_tiles = new List<Hex>();
        path_tiles = new List<Hex>();
    }
    public List<Hex> PathFinding(Hex _start, Hex _end)
    {
        TileClear();
        start_tile = _start;
        end_tile = _end;
        open_tiles.Add(start_tile);
        Hex current = start_tile;
        start_tile.SetCost(-1, Mathf.Abs(start_tile.GetX - end_tile.GetX) + Mathf.Abs(start_tile.GetY - end_tile.GetY)) ;

        while (open_tiles.Any())
        {
            current = open_tiles[0];
            foreach (Hex t in open_tiles)
            {
                if(t.GetF<current.GetF||t.GetF==current.GetF&&t._H<=current._H)
                {
                    current = t;
                }
            }
            if(current.ID==end_tile.ID)
            {
                GetPathList(end_tile);
                return path_tiles;
            }
            close_tiles.Add(current);
            open_tiles.Remove(current);
            SetMovePrice(current);
        }
        return null;

    }
    void SetMovePrice(Hex _curtile)
    {
        bool find = false;
        int index = 0;

        foreach (Hex tile in _curtile.GetAroundTile())
        {

            foreach (Hex close in close_tiles)
            {
                if (tile.ID == close.ID)
                {
                    find = true;
                    index++;
                    continue;
                }
            }
            int cur_gcost = -1;
            int cur_hcost = -1;
            bool inSearch = false;
            //close 목록에 없고 벽이 아니면 계산하기.
            if (find == false && tile._TileType == Hex.TileType.Move)
            {
                inSearch = open_tiles.Contains(tile);

                cur_gcost = _curtile._G + cost1;
                if (!inSearch || cur_gcost < tile._G)
                {
                    tile.SetParent(_curtile);
                    
                    if(!inSearch)
                    {
                        cur_hcost = (Mathf.Abs(tile.GetX - end_tile.GetX) + Mathf.Abs(tile.GetY - end_tile.GetY));
                        open_tiles.Add(tile);
                    }
                }
                else
                {
                    cur_gcost = -1;
                }

                tile.SetCost(cur_gcost, cur_hcost);
              
            }
            if (find == true)
                find = false;
            index++;
        }
    }
    void GetPathList(Hex _endtile)
    {
        List<Hex> templist = new List<Hex>();
        Hex temptile = _endtile;
        while(temptile.Prev !=null)
        {
            templist.Add(temptile);
            temptile = temptile.Prev;
        }
        int size = templist.Count;
        for(int i=size-1;i>=0;i--)
        {
            path_tiles.Add(templist[i]);
        }
        
    }
    void SetCurrentTile(Hex _curtile)
    {

    }
    void TileClear()
    {
        MapManager.Instance.FindingClear();
    }
}
