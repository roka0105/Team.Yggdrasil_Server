#pragma once
#include "GameObject.h"
class Boss : public GameObject
{
public:
	Boss();
	~Boss();

private:

};

