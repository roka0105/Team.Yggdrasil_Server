#include "pch.h"
#include "CLockGuard_Static.h"