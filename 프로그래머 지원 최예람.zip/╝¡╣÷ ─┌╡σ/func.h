#pragma once

void err_display(const TCHAR* msg);
void err_quit(const TCHAR* msg);
