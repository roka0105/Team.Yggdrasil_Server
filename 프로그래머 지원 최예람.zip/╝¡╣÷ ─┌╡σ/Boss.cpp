#include "pch.h"
#include "Boss.h"

Boss::Boss()
{
}

Boss::~Boss()
{
}
