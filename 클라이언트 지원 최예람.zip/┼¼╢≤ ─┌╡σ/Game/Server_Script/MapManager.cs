using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

using EMainProtocol = Net.Protocol.EMainProtocol;
using EProtocolType = Net.Protocol.EProtocolType;
using ESubProtocol = Game_Manager.ESubProtocol;
using EDetailProtocol = Game_Manager.EDetailProtocol;
using AroundType = Hex.AroundType;
public class MapManager : Singleton_Ver2.Singleton<MapManager>
{
    [SerializeField]
    LineRenderer lineprefeb;
    [SerializeField]
    Transform parent;
    Vector3 startpos = new Vector3(0, 0, 0);
    List<LineRenderer> lines;
    List<Hex> hexs;
    float radius = 17;
    float offset_1 = 0f;
    float offset_2 = 17f;

    int row = 6;
    int col = 5;
    int around_count = 6;
    static Hex dummy_tile;
    List<int> test_wall_index;
    #region server Init
    /*private void CreateMap()
    {
        for (int i = 0; i < 5; i++)
        {
            int number = 8;
            for (int j = 0; j < number; j++)
            {
                float offset = i % 2 == 0 ? offset_1 : offset_2;
                Vector3 temppos = new Vector3(startpos.x + (j * radius * 1.8f) - offset, 0f, startpos.z - (i * radius * 1.6f));
                Hex hex = new Hex(temppos, radius, around_count);
                hex.CreateVertex();
                hexs.Add(hex);
                //벽으로 지정된 타일인지
                int index = hexs.Count - 1;
                hexs[index].ID = index;
                if (test_wall_index.Find(_index => _index == index) != 0)
                {
                    hexs[index]._TileType = Hex.TileType.Wall;
                }
            }
        }
    }*/
    #endregion
    private void CreateMap()
    {
        for (int i = 0; i < 5; i++)
        {
            int number = 6;
            for (int j = 0; j < number; j++)
            {
                float offset = i % 2 == 0 ? offset_1 : offset_2;
                Vector3 temppos = new Vector3(startpos.x + (j * radius * 1.8f) - offset, 0f, startpos.z - (i * radius * 1.6f));
                Hex hex = new Hex(temppos, radius, around_count);
                hex.CreateVertex();
                hexs.Add(hex);
                //벽으로 지정된 타일인지
                int index = hexs.Count - 1;
                hexs[index].ID = index;
                if (test_wall_index.Find(_index => _index == index) != 0)
                {
                    hexs[index]._TileType = Hex.TileType.Wall;
                }
            }
        }
    }
    private void AroundTileSetting()
    {
        int index = 0;

        for (int i = 0; i < hexs.Count; i++)
        {

            int cur_col = index / around_count;
            int cur_row = index % around_count;

            if (cur_col % 2 == 0)
            {
                SetAround_Step1(index, cur_col, cur_row, false);
                SetAround_Step2(index, cur_col, cur_row, false);
            }
            else
            {
                SetAround_Step1(index, cur_col, cur_row, true);
                SetAround_Step2(index, cur_col, cur_row, true);
            }
            ++index;
        }

    }
    private bool UseIndex(int _origin_index, int _index, int _col, int _row, bool _curtype)
    {
        int curline = _col * around_count;
        int leftup_min = curline - (around_count + 1);
        int leftdown_max = curline + (around_count - 1);
        int righttup_min = curline - 1;
        int rightdown_max = curline + (around_count*2);
        int left = curline - 1;
        int right = curline + (around_count);
        bool leftflag = (curline == _origin_index) ? true : false;
        bool rightflag = (right - 1 == _origin_index) ? true : false;
        if (_index >= 0 && _index < row * col)
        {
            if (_curtype && (leftflag || rightflag))
            {
                if (leftflag)
                {
                    if (_index != leftup_min && _index != leftdown_max && _index != left)
                    {
                        return true;
                    }
                }
                else if (rightflag)
                {
                    if (_index != right)
                    {
                        return true;
                    }
                }
            }
            else if (rightflag)
            {
                if (_index != rightdown_max && _index != righttup_min + 1 && _index != right)
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }

        return false;
    }
    private void SetAround_Step1(int _index, int _col, int _row, bool _curtype)
    {
        int use_index = 0;
        if (_curtype)
        {
            use_index = _index - (around_count + 1);
        }
        else
        {
            use_index = _index - (around_count);
        }

        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.LeftUp);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.LeftUp);
        }

        if (_curtype)
        {
            use_index = _index - around_count;
        }
        else
        {
            use_index = _index - around_count + 1;
        }

        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.RightUp);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.RightUp);
        }

        if (_curtype)
        {
            use_index = _index + (around_count - 1);
        }
        else
        {
            use_index = _index + (around_count);
        }

        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.LeftDown);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.LeftDown);
        }
        if (_curtype)
        {
            use_index = _index + around_count;
        }
        else
        {
            use_index = _index + around_count + 1;
        }
        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.RightDown);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.RightDown);
        }

        use_index = _index - 1;
        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.Left);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.Left);
        }
        use_index = _index + 1;
        if (UseIndex(_index, use_index, _col, _row, _curtype))
        {
            hexs[_index].AddAroundTile(hexs[use_index], AroundType.Right);
        }
        else
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.Right);
        }
    }
    private void SetAround_Step2(int _index, int _col, int _row, bool _curtype)
    {
        //맨 왼쪽
        if (_row == 0)
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.Left);
            if (_curtype)
            {
                hexs[_index].AddAroundTile(dummy_tile, AroundType.LeftUp);
                hexs[_index].AddAroundTile(dummy_tile, AroundType.LeftDown);
            }
        }//맨 오른쪽
        else if (_index == (around_count * _col) - 1)
        {
            hexs[_index].AddAroundTile(dummy_tile, AroundType.Right);
            if (_curtype == false)
            {
                hexs[_index].AddAroundTile(dummy_tile, AroundType.RightUp);
                hexs[_index].AddAroundTile(dummy_tile, AroundType.RightDown);
            }
        }
    }


    #region send func
    public void InitRequest()
    {
        Net.Protocol protocol = new Net.Protocol();
        protocol.SetProtocol((uint)EMainProtocol.INIT, EProtocolType.Main);
        protocol.SetProtocol((uint)ESubProtocol.Object, EProtocolType.Sub);
        protocol.SetProtocol((uint)EDetailProtocol.Tile, EProtocolType.Detail);

        int count = hexs.Count;
        int size = 0;
        Net.NetVector netvector = new Net.NetVector();

        Net.SendPacket sendpacket = new Net.SendPacket();
        sendpacket.__Initialize();
        size += sendpacket.Write(count);
        size += sendpacket.Write(Hex.Radius);
        foreach (var hex in hexs)
        {
            netvector.Vector = hex.SenterPos;
            size += sendpacket.Write(netvector);
        }
        sendpacket.WriteProtocol(protocol.GetProtocol());
        sendpacket.WriteTotalSize(size);
        Net.NetWorkManager.Instance.Send(sendpacket);
    }
    #endregion
    #region recv func
    public void TestTileResult(Net.RecvPacket _recvpacket)
    {
        int datasize = 0;
        List<Net.NetVector> startpos_s = new List<Net.NetVector>();

        int sectorcount = 0;
        _recvpacket.Read(out datasize);
        _recvpacket.Read(out sectorcount);
        Net.NetVector net_distance = new Net.NetVector();
        _recvpacket.ReadSerialize(out net_distance);
        for (int i = 0; i < sectorcount; i++)
        {
            Net.NetVector startpos = new Net.NetVector();
            _recvpacket.ReadSerialize(out startpos);
            startpos_s.Add(startpos);
        }
        int suc = 0;
        int count = startpos_s.Count;
        int size = lines.Count;
        for (int i = 0; i < size; i++)
        {
            LineRenderer item = lines[0];
            lines.RemoveAt(0);
            DestroyObject(item);
        }
        lines.Clear();
        for (int i = 0; i < count; i++)
        {
            Vector3 pos;
            pos.x = startpos_s[i].x;
            pos.y = startpos_s[i].y;
            pos.z = startpos_s[i].z;

            foreach (var tile in hexs)
            {
                if (tile.SenterPos == pos)
                {
                    DrawLine(tile);
                    ChageColor_Hex(suc++, Color.red);
                    break;
                }
            }
        }
        //spawn point
        //StageManager.GetObjectWorldPos Init_info = MainManager.Instance.GetStageManager().m_GetWorldPosByObjects;
        //Game_Manager.Instance.InitPlayer(Init_info.PlayerPos);
        //Game_Manager.Instance.InitBoss(Init_info.bossPos);
        //Game_Manager.Instance.InitItem(Init_info.ItemPos);
    }
    public void InitResult(Net.RecvPacket _recvpacket)
    {
        //spawn point
        StageManager.GetObjectWorldPos Init_info = MainManager.Instance.GetStageManager().m_GetWorldPosByObjects;
        Game_Manager.Instance.InitPlayer(Init_info.PlayerPos);
        Game_Manager.Instance.InitBoss(Init_info.bossPos);
        Game_Manager.Instance.InitItem(Init_info.ItemPos);
    }
    #endregion

    #region Draw Tile
    public void DrawLine(Hex _hex)
    {
        Vector3[] vertexs = _hex.GetVertex;
        LineRenderer item = GameObject.Instantiate<LineRenderer>(lineprefeb, parent);
        int linecount = 0;
        for (int i = 0; i < vertexs.Length; i++)
        {
            AddLine(ref linecount, ref item);
            if (i == vertexs.Length - 1)
            {
                item.SetPosition(linecount - 1, vertexs[i]);
                AddLine(ref linecount, ref item);
                item.SetPosition(linecount - 1, vertexs[0]);
                break;
            }
            item.SetPosition(linecount - 1, vertexs[i]);
            AddLine(ref linecount, ref item);
            item.SetPosition(linecount - 1, vertexs[i + 1]);
        }
        lines.Add(item);
    }
    private void AddLine(ref int _linecount, ref LineRenderer _line)
    {
        _linecount++;
        _line.positionCount = _linecount;
    }
    private void ChageColor_Hex(int _index, Color _color)
    {
        lines[_index].startColor = _color;
        lines[_index].endColor = _color;
    }
    public Hex FindTile(Vector3 _objpos)
    {
        bool check = false;
        for (int i = 0; i < hexs.Count; i++)
        {
            check = hexs[i].InHex(_objpos);
            if (check)
            {
                return hexs[i];
            }
        }
        return null;
    }
    public void InObjectCheck(Vector3 _objpos)
    {
        bool check = false;
        for (int i = 0; i < hexs.Count; i++)
        {
            check = hexs[i].InHex(_objpos);
            if (check == true)
            {
                ChageColor_Hex(i, Color.red);
            }
            else
            {
                ChageColor_Hex(i, Color.green);
            }
        }
    }
    public void FindingClear()
    {
        foreach (var tile in hexs)
        {
            tile.FindingClear();
        }
    }

    #endregion
    // Start is called before the first frame update
    void Start()
    {
        lines = new List<LineRenderer>();
        hexs = new List<Hex>();

        test_wall_index = new List<int>();
        test_wall_index.Add(5);
        test_wall_index.Add(6);
        test_wall_index.Add(8);
        test_wall_index.Add(9);
        test_wall_index.Add(11);
        test_wall_index.Add(12);
        test_wall_index.Add(15);
        test_wall_index.Add(17);
        test_wall_index.Add(19);
        test_wall_index.Add(22);
        test_wall_index.Add(27);
        dummy_tile = new Hex(-1);
        dummy_tile._TileType = Hex.TileType.Wall;
        CreateMap();
        //foreach (var tile in hexs)
        //DrawLine(tile);
        AroundTileSetting();

        hexs[7].PrintAround();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
