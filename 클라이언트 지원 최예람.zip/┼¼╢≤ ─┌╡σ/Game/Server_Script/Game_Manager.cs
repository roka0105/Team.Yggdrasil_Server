using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using EProtocolType = Net.Protocol.EProtocolType;
using EMainProtocol = Net.Protocol.EMainProtocol;
public class Game_Manager : Singleton_Ver2.Singleton<Game_Manager>
{
    public enum ESubProtocol
    {
        None,
        Sector,
        Object,
        Max
    }
    public enum EDetailProtocol
    {
        None,
        Tile,
        Player,
        Boss,
        Item,
    }
    #region send func
    public void InitReqest()
    {
        //sector 
        SectorManager.Instance.InitRequest();
    }
    public void TestViewSector(Vector3 _objpos)
    {
        SectorManager.Instance.TestViewSector(_objpos);
    }
    public void TestMovePlayer(Vector3 _offset)
    {
        Net.Protocol protocol = new Net.Protocol();
        protocol.SetProtocol((uint)EMainProtocol.TEST, EProtocolType.Main);
       
        Net.SendPacket sendpacket = new Net.SendPacket();
        sendpacket.__Initialize();
        Net.NetVector netvector = new Net.NetVector();
        netvector.Vector = _offset;
        int size = 0;
        size += sendpacket.Write(netvector);
        sendpacket.WriteProtocol(protocol.GetProtocol());
        sendpacket.WriteTotalSize(size);
        Net.NetWorkManager.Instance.Send(sendpacket);
    }
    public void InitPlayer(Vector3 _playerpos)
    {
        Net.Protocol protocol = new Net.Protocol();
        protocol.SetProtocol((uint)EMainProtocol.INIT, EProtocolType.Main);
        protocol.SetProtocol((uint)ESubProtocol.Object, EProtocolType.Sub);
        protocol.SetProtocol((uint)EDetailProtocol.Player, EProtocolType.Detail);

        Net.SendPacket sendpacket = new Net.SendPacket();
        sendpacket.__Initialize();
        Net.NetVector netvector = new Net.NetVector();
        netvector.Vector = _playerpos;
        int size = 0;
        //player 스폰 위치 세개 전송.
        //list count 전송 근데 지금은 player 1개의 정보만 주시기 때문에 count 1로 해두자.
        int count = 1;
        size += sendpacket.Write(count);
        size += sendpacket.Write(netvector);

        sendpacket.WriteProtocol(protocol.GetProtocol());
        sendpacket.WriteTotalSize(size);
        Net.NetWorkManager.Instance.Send(sendpacket);
    }
    public void InitBoss(Vector3 _bosspos)
    {
        Net.Protocol protocol = new Net.Protocol();
        protocol.SetProtocol((uint)EMainProtocol.INIT, EProtocolType.Main);
        protocol.SetProtocol((uint)ESubProtocol.Object, EProtocolType.Sub);
        protocol.SetProtocol((uint)EDetailProtocol.Boss, EProtocolType.Detail);

        Net.SendPacket sendpacket = new Net.SendPacket();
        sendpacket.__Initialize();
        Net.NetVector netvector = new Net.NetVector();
        netvector.Vector = _bosspos;
        int size = 0;
        size += sendpacket.Write(netvector);
        sendpacket.WriteProtocol(protocol.GetProtocol());
        sendpacket.WriteTotalSize(size);
        Net.NetWorkManager.Instance.Send(sendpacket);
    }
    public void InitItem(Vector3 _itempos)
    {
        //아이템도 종류가 여럿이면 list로 받아오기.
        Net.Protocol protocol = new Net.Protocol();
        protocol.SetProtocol((uint)EMainProtocol.INIT, EProtocolType.Main);
        protocol.SetProtocol((uint)ESubProtocol.Object, EProtocolType.Sub);
        protocol.SetProtocol((uint)EDetailProtocol.Item, EProtocolType.Detail);

        Net.SendPacket sendpacket = new Net.SendPacket();
        sendpacket.__Initialize();
        Net.NetVector netvector = new Net.NetVector();
        netvector.Vector = _itempos;
        int size = 0;
        int count = 1;
        // item 주시면 list 일것이니까 count 정보도 패킷에 넣기.
        size += sendpacket.Write(count);
        size += sendpacket.Write(netvector);
        sendpacket.WriteProtocol(protocol.GetProtocol());
        sendpacket.WriteTotalSize(size);
        Net.NetWorkManager.Instance.Send(sendpacket);
    }
    #endregion
    #region recv func
    public void InItResult(Net.RecvPacket _recvpacket, uint _protocol)
    {
        Net.Protocol protocol_manager = new Net.Protocol(Convert.ToUInt32(_protocol));
        uint subprotocol = protocol_manager.GetProtocol(EProtocolType.Sub);
        switch ((ESubProtocol)subprotocol)
        {
            case ESubProtocol.Sector:
                SectorManager.Instance.InitResult(_recvpacket);
                break;
            case ESubProtocol.Object:
                InitObjectResult(_recvpacket, protocol_manager);
                break;
        }

    }
    public void TestResult(Net.RecvPacket _recvpacket,uint _protocol)
    {
        Net.Protocol protocol_manager = new Net.Protocol(Convert.ToUInt32(_protocol));
        uint subprotocol = protocol_manager.GetProtocol(EProtocolType.Sub);
        uint detailprotocol = protocol_manager.GetProtocol(EProtocolType.Detail);
        switch((ESubProtocol)subprotocol)
        {
            case ESubProtocol.Sector:
                SectorManager.Instance.TestViewSectorResult(_recvpacket);
                break;
            case ESubProtocol.Object:
                switch((EDetailProtocol)detailprotocol)
                {
                    case EDetailProtocol.Tile:
                        MapManager.Instance.TestTileResult(_recvpacket);
                        break;
                }
                break;
        }
       
    }

    private void InitObjectResult(Net.RecvPacket _recvpacket, Net.Protocol _protocol)
    {
        uint detailprotocol = _protocol.GetProtocol(EProtocolType.Detail);
        int datasize = 0;
        int count = 0;
        Net.NetVector netvector = new Net.NetVector();
        switch ((EDetailProtocol)detailprotocol)
        {
            case EDetailProtocol.Tile:
                MapManager.Instance.InitResult(_recvpacket);
                break;
            case EDetailProtocol.Player:
                _recvpacket.Read(out datasize);
                _recvpacket.Read(out count);
                for (int i = 0; i < count; i++)
                    _recvpacket.ReadSerialize(out netvector);
                Vector3 vec = netvector.Vector;
                GameGUIManager.Instance.TestPlayerPos(vec);
                break;
            case EDetailProtocol.Boss:
                _recvpacket.Read(out datasize);
                _recvpacket.Read(out count);
                for (int i = 0; i < count; i++)
                    _recvpacket.ReadSerialize(out netvector);
                Vector3 vec2 = netvector.Vector;
                GameGUIManager.Instance.TestBossPos(vec2);
                break;
            case EDetailProtocol.Item:
                break;
        }
    }
    #endregion 
}

