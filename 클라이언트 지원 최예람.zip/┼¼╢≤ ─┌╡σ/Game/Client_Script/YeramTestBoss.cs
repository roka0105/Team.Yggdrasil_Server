using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YeramTestBoss : MonoBehaviour
{
    IEnumerator move_coroutine;
    Vector3 targetpos;
    bool requestflag = true;
    bool moveflag = false;
    IEnumerator Move(List<Hex> movetile)
    {
        while(true)
        {
            if (movetile.Count != 0 && requestflag == true)
            {
                requestflag = false;
                moveflag = true;
                Hex tile = movetile[0];
                movetile.Remove(tile);
                targetpos = tile.SenterPos;
            }
            else if (movetile.Count == 0)
            {
                moveflag = false;
            }
            yield return null;
        }
    }
    public void MoveBoss(List<Hex> movetile)
    {
        move_coroutine = Move(movetile);
        StartCoroutine(move_coroutine);
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(moveflag)
        {
            Vector3 speed = Vector3.zero;
            this.gameObject.transform.position = Vector3.SmoothDamp(this.gameObject.transform.position, targetpos, ref speed, 0.1f);
            if (Mathf.Round(this.gameObject.transform.position.x) == Mathf.Round(targetpos.x)&& Mathf.Round(this.gameObject.transform.position.z)== Mathf.Round(targetpos.z))
                requestflag = true;
        }
        else
        {
            if(move_coroutine!=null)
            StopCoroutine(move_coroutine);
        }
    }
}
