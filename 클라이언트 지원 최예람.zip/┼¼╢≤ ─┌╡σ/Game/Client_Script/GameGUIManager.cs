using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameGUIManager : Singleton_Ver2.Singleton<GameGUIManager>
{
    //test 임시 오브젝트
    [SerializeField]
    GameObject TestObject;
    [SerializeField]
    GameObject TestObject2;
    List<Hex> move_pos;
    Vector3 cur_pos;
    #region click event
    public void Click_ViewSector()
    {
        Game_Manager.Instance.TestViewSector(TestObject.transform.position);
    }
    public void Click_MovePlayer()
    {
        Game_Manager.Instance.TestMovePlayer(TestObject.transform.position);
    }
    #endregion

    public void TestPlayerPos(Vector3 vec)
    {
        TestObject.transform.position = vec;
    }
    public void TestBossPos(Vector3 vec)
    {
        TestObject2.transform.position = vec;
    }

    public void OnClickPathFind()
    {
        #region
        Hex start = MapManager.Instance.FindTile(TestObject.transform.position);
        Hex end = MapManager.Instance.FindTile(TestObject2.transform.position);
        AStarYR a_star = new AStarYR(start, end);
        #endregion
        move_pos = a_star.PathFinding(start,end);

        foreach (var tile in move_pos)
        {
            MapManager.Instance.DrawLine(tile);
        }

        YeramTestBoss boss = TestObject.GetComponent<YeramTestBoss>();
        boss.MoveBoss(move_pos);
    }
    // Start is called before the first frame update
    void Start()
    {
        StageManager.GetObjectWorldPos Init_info = MainManager.Instance.GetStageManager().m_GetWorldPosByObjects;
        Init_info.PlayerPos = TestObject.transform.position;
        Init_info.bossPos = TestObject2.transform.position;
        move_pos = new List<Hex>();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
