#include "pch.h"
#include "CLockGuard.h"

//template<typename T>
//CLockGuard<T>::CLockGuard(T* a)
//	: m_key(a)
//{
//	a->lock();
//}
//
//template<typename T>
//CLockGuard<T>::~CLockGuard()
//{
//	m_key->unlock();
//}


