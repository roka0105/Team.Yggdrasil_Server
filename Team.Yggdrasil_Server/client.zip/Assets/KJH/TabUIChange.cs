using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine;

public class TabUIChange : MonoBehaviour
{
    EventSystem system;
    public Selectable FirstInput;                                       //��ǲ�ʵ� ������Ʈ
    public Button OkButton;                                             //Ȯ�ι�ư ������Ʈ
    public Button BackButton;                                           //�ڷΰ����ư ������Ʈ
    // Start is called before the first frame update
    void Start()
    {
        system = EventSystem.current;
        FirstInput.Select();                                            //ó���� ID�Է�
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab) && Input.GetKey(KeyCode.LeftShift))                             //LEFTShift + Tab�ϸ� �����׸����� �̵�
        {
            Selectable next = system.currentSelectedGameObject.GetComponent<Selectable>().FindSelectableOnUp();
            if(next != null)
            {
                next.Select();
            }
            
        }
        else if (Input.GetKeyDown(KeyCode.Tab))                                                           //Tab �ϸ� �Ʒ��׸����� �̵�
        {
            Selectable next = system.currentSelectedGameObject.GetComponent<Selectable>().FindSelectableOnDown();
            if (next != null)
            {
                next.Select();
            }
        }
        else if (Input.GetKeyDown(KeyCode.Return))                                                        //Enter �ϸ� �α��� ��ư Ŭ��
        {
            // ����Ű�� ġ�� �α��� (����) ��ư�� Ŭ��
            OkButton.onClick.Invoke();
            Debug.Log("OKButton pressed!");
        }
        else if (Input.GetKeyDown(KeyCode.Backspace))
        {
            BackButton.onClick.Invoke();
            Debug.Log("BackButton pressed!");
        }
    }
}
