using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RoomUI : MonoBehaviour
{
    public Button[] CellBtn;
    public Button PreBtn, NextBtn;
    public List<string> roomList = new List<string>() { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" };

    int currentPage = 1;
    int maxPage;
    int multiple;

    // Start is called before the first frame update
    void Start()
    {
        //�ִ�������
        if(roomList.Count % CellBtn.Length == 0)
        {
            maxPage = roomList.Count / CellBtn.Length;
        }
        else
        {
            maxPage = roomList.Count / CellBtn.Length + 1;
        }

        //���� ������ư
        if (currentPage <= 1)
        {
            PreBtn.interactable = false;
        }
        else{
            PreBtn.interactable = true;
        }
        if (currentPage >= maxPage)
        {
            NextBtn.interactable = false;
        }
        else
        {
            NextBtn.interactable = true;
        }

        //�������� ���� ����Ʈ ����
        multiple = (currentPage - 1) * CellBtn.Length;
        for(int i = 0; i < CellBtn.Length; i++)
        {
            if (multiple + i < roomList.Count)
            {
                CellBtn[i].interactable = true;
            }
            else
            {
                CellBtn[i].interactable = false;
            }
            if (multiple + i < roomList.Count)
            {
                CellBtn[i].GetComponentInChildren<TMPro.TextMeshProUGUI>().text = roomList[multiple + i];
            }
            else
            {
                CellBtn[i].GetComponentInChildren<TMPro.TextMeshProUGUI>().text = "";
            }
        }
    }
    public void BtnClick(int num)
    {
        if(num == -2)
        {
            --currentPage;
        }
        else if (num == -1)
        {
            ++currentPage;
        }
        else
        {
            print(roomList[multiple + num]);
        }
        Start();
    }

    [ContextMenu("����Ʈ �߰�")]
    void ListAdd()
    {
        roomList.Add("�ָ�ũ");
        Start();
    }

    [ContextMenu("����Ʈ ����")]
    void ListRemove()
    {
        roomList.RemoveAt(0);
        Start();
    }
}
